-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 21, 2017 at 03:41 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `pid` int(3) NOT NULL,
  `name` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `age` int(2) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `disease` varchar(20) NOT NULL,
  `No` int(3) NOT NULL,
  `date` date NOT NULL,
  `building` varchar(10) NOT NULL,
  `roomno` int(2) NOT NULL,
  `unitprice` int(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date2` varchar(20) NOT NULL DEFAULT '',
  `price` int(5) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `No` (`No`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`pid`, `name`, `gender`, `age`, `phone`, `address`, `disease`, `No`, `date`, `building`, `roomno`, `unitprice`, `status`, `date2`, `price`) VALUES
(100, 'JOSEPH', 'MALE', 20, 7404129459, 'NEW YORK CITY', 'CHOLERA', 1, '2011-01-01', 'A', 1, 30, 'WELL', '2012-01-01', 60),
(101, 'GEORGE', 'MALE', 21, 9996279302, 'CALIFORNIA TEXAS', 'MALARIA', 2, '2011-02-01', 'B', 2, 20, 'BETTER', '2011-8-9', 50),
(102, 'MICHAEL', 'MALE', 23, 9857346274, 'VENDA MARKET,NEW YORK', 'TYPHOID', 3, '2011-03-01', 'A', 3, 40, 'BETTER', '2010-02-01', 70),
(103, 'SHWAN', 'FEMALE', 22, 7206439893, 'CALIFORNIA TEXAS', 'MALARIA', 4, '2011-04-10', 'B', 3, 30, 'BETTER', '2011-05-01', 40),
(104, 'Ravi Misra', 'MALE', 34, 7408439893, 'kalka', 'MALARIA', 7, '2011-01-01', 'B', 5, 10, '', '', 0),
(105, 'rohan', 'male', 21, 9882731173, 'kalka', 'cholera', 6, '2002-09-13', 'C', 4, 20, 'Well', '2002-09-13', 0),
(107, 'karan', 'male', 20, 8989906676, 'parwanoo', 'Cholera', 8, '2009-05-05', 'C', 4, 20, 'Well', '2009-05-05', 0),
(108, 'seema', 'female', 20, 9728988704, 'chandigarh', 'Malaria', 10, '2008-02-02', 'C', 5, 30, 'WELL', '2008-02-02', 0),
(109, 'sheena', 'Female', 30, 9888909444, 'Chandigarh', 'Cholera', 11, '2003-03-03', 'B', 4, 20, 'WELL', '2003-03-03', 0),
(110, 'sheena', 'female', 12, 8988904987, 'new York', 'Cholera', 9, '2009-02-02', 'C', 3, 40, 'Well', '2009-02-02', 0),
(343, 'yoh', 'male', 20, 9996793402, 'hh', 'malaria', 5, '1999-08-08', 'B', 3, 29, '', '0000-00-00', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
